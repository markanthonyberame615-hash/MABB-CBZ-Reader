package org.koitharu.kotatsu.local.ui

import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.core.ui.BaseActivity
import org.koitharu.kotatsu.databinding.ActivityContainerBinding
import org.koitharu.kotatsu.local.data.importer.SingleMangaImporter
import javax.inject.Inject

/**
 * Entry point for CBZ files opened from Android file managers.
 *
 * The file is imported using the existing local-storage importer and then handed
 * to the normal reader, so the existing CBZ reader and download flows are unchanged.
 */
@AndroidEntryPoint
class ExternalCbzActivity : BaseActivity<ActivityContainerBinding>() {

	@Inject
	lateinit var importer: SingleMangaImporter

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(ActivityContainerBinding.inflate(layoutInflater))
		setTitle(R.string.app_name)

		val uri = intent.data
		if (uri == null) {
			finish()
			return
		}

		lifecycleScope.launch {
			try {
				val manga = importer.importExternalFile(uri).manga
				router.openReader(manga)
			} catch (error: Throwable) {
				Toast.makeText(
					this@ExternalCbzActivity,
					error.message ?: getString(R.string.error_occurred),
					Toast.LENGTH_LONG,
				).show()
			} finally {
				finish()
			}
		}
	}
}
